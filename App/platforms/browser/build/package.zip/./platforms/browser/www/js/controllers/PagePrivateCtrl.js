app.controller('PagePrivateCtrl', function($scope){
    $scope.h1 = 'Private';
});
