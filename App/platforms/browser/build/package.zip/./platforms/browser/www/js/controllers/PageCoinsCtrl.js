app.controller('PageCoinsCtrl', function($scope){
    $scope.h1 = 'COINS';
});
