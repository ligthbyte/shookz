app.controller('HomeCtrl', function($scope){
    $scope.currentView = 'main';
    $scope.mainPopupState = false;
    $scope.mainPopupTitle = 'כותרת';
    $scope.mainPopupCaption = 'סתם מלא טקסט סתם מלא טקסט סתם מלא טקסט סתם מלא טקסט סתם מלא טקסט.';
    $scope.mainPopupCloseBtnText = 'סגור';
    $scope.mainPopupConfirmBtnText = 'אישור';
    $scope.location = 'טוען את מיקומך...';

    var getUserLocation = function() {
        navigator.geolocation.getCurrentPosition(
            function(position) {
                nativegeocoder.reverseGeocode(
                    function (result) {
                        var city = result[0].locality;
                        var streetName = result[0].thoroughfare;
                        var streetNumber = result[0].subThoroughfare;
                        $scope.location = streetName + ' ' + streetNumber + ', ' + city;
                        $scope.$apply();
                    },
                    function (err) {
                        console.log(JSON.stringify(err));
                        $scope.location = 'מיקומך אינו זמין, הזן ידנית.';
                        $scope.mainPopupState = true;                        
                        $scope.$apply();
                    },
                    position.coords.latitude,
                    position.coords.longitude,
                    { useLocale: true, maxResults: 1 }
                );
            }, function(error) {
                $scope.location = 'מיקומך אינו זמין, הזן ידנית.';
                $scope.mainPopupState = true;
                $scope.$apply();
            },
            { timeout: 5000, enableHighAccuracy: true }
        );    
    }

    getUserLocation();
});
