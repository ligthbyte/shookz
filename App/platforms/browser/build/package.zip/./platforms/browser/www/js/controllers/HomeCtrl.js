app.controller('HomeCtrl', function($scope){
    $scope.currentView = 'main';
});
